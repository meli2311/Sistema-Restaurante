
package Modelo;

/**
 *
 * @author Yonatan
 */
public class usuarios {
    
    private String usuario;
    private String password;
    private String nivelacceso; 

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNivelacceso() {
        return nivelacceso;
    }

    public void setNivelacceso(String nivelacceso) {
        this.nivelacceso = nivelacceso;
    }
   
    
}
